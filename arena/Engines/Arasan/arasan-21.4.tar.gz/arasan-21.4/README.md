This repository contains source code for Arasan. Arasan is a chess engine, that is, a console-based program 
that plays the game of chess.

By itself, it has no graphical interface, but can be used together with interface programs such as xboard
and Winboard.

Arasan's source language is C++. It is multi-platform (Windows, Linux, Mac OS, Unix) and supports
multi-threading for higher performance.

It is licensed under the MIT License. See the doc subdirectory for license details and additional documentation.
