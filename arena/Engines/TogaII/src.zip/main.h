#ifndef MAIN_H_

#define MAIN_H_

//#define LOCK

#pragma warning( disable : 4100 )
// Level 4 unreferenced formal parameter -> input.cpp/egtb.cpp/tbdecode.h

char file_name[256];

#endif // MAIN_H_
